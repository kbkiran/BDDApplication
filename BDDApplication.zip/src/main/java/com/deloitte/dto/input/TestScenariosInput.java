package com.deloitte.dto.input;

import java.util.ArrayList;
import java.util.List;


public class TestScenariosInput {

	private List<TestScenarioInput> testScenarios = new ArrayList<TestScenarioInput>();


	public List<TestScenarioInput> getTestScenarios() {
		return testScenarios;
	}

	public void setTestScenarios(List<TestScenarioInput> testScenarios) {
		this.testScenarios = testScenarios;
	}

}
